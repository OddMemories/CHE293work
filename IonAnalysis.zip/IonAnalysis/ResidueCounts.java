import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class ResidueCounts {

    public ResidueCounts() {
        // TODO Auto-generated constructor stub
    }

    private static void help() {
        System.out.println("java ResidueCounts <residue count csv directory>");
        System.exit(-1);
    }

    /*
        Identify the csv file which does not have ion
    */
    public static ArrayList<File> getFileListNotContainingIon (File directory) throws IOException {

        ArrayList<File> filesNotContainingIon = new ArrayList<>();
        for (File file : directory.listFiles()) {
           if(file.isHidden()) {
            continue;
           } 
           Scanner sc = new Scanner(file);
           boolean foundFileNotContainingIon = true;
           sc.nextLine();
           while (sc.hasNextLine()) {
               String[] columns = sc.nextLine().split(",");
               String key = columns[0];
               if (columns[0].equals("MG") || columns[0].equals("MN") || columns[0].equals("NA") 
                  || columns[0].equals("ZN") || columns[0].equals("CA") || columns[0].equals("K")) {
                  foundFileNotContainingIon = false;
                  break;
               }
           }

           if (foundFileNotContainingIon) {
                filesNotContainingIon.add(file);
           }
        }
        return filesNotContainingIon;
    }
    
    /*
        Identify the csv file which does not have ion
    */
    public static ArrayList<File> getFileListFromDirectory (File directory) throws IOException {

        ArrayList<File> files = new ArrayList<>();
        for (File file : directory.listFiles()) {
           files.add(file);
        }
        return files;
    }

    public static void main(String[] args) throws IOException {

        if(args.length == 0) {
          help();  
        }
        File dir = new File(args[0]);
        if (!dir.isDirectory()) {
            System.out.println(dir.getAbsolutePath() + " is not a directory. Exiting...");
            System.exit(-1);
        }
        System.out.println("Residue Count csv Directory name: " + dir.getCanonicalPath());

        

        Map<String, ArrayList<Integer>> map = new HashMap<>();
        StringBuffer header = new StringBuffer();
        header.append(" ");
        int j = 0;
        //for (File file : dir.listFiles()) {
        for (File file : getFileListNotContainingIon(dir)) {
           if(file.isHidden()) {
            continue;
           } 
           Scanner sc = new Scanner(file);
           header.append(",");
           header.append(file.getName());
           //System.out.println("filename = " + file.getName());
           sc.nextLine();
           while (sc.hasNextLine()) {
               String[] columns = sc.nextLine().split(",");
               String key = columns[0];
               int count = Integer.parseInt(columns[1]);
               
               if(!map.containsKey(key)) {
                   ArrayList<Integer> countList = new ArrayList<>();
                   for (int i = 0; i < j - 1; i++) {
                       countList.add(0);
                   }
                   countList.add(count);
                   map.put(key, countList);
               }
               else {
                   map.get(key).add(count);
               }
               
               for(Map.Entry<String, ArrayList<Integer>> entry : map.entrySet()) {
                   if (entry.getValue().size() < j) {
                       entry.getValue().add(0);
                   }
               }
  
           }
           sc.close();
           j++;
        }
        for(Map.Entry<String, ArrayList<Integer>> entry : map.entrySet()) {
            if (entry.getValue().size() < j) {
                entry.getValue().add(0);
            }
        }
        
        try (BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("ResidueOutputs.csv"), "UTF-8"))) {
            bw.write(header.toString());
            bw.newLine();
            for(Map.Entry<String, ArrayList<Integer>> entry : map.entrySet()) {
                bw.write(entry.getKey()); 
                for(Integer value: entry.getValue()) {
                    bw.write(",");
                    bw.write(value.toString());
                } 
                bw.newLine();
            }

       } catch (IOException ex) {
           ex.printStackTrace();
       }
        
       System.out.println("Program completed...");
      
    }

}
/*
 * AH 3
 * BJ 4
 * CD 5
 * Map: j = 0
 * AH, [3]
 * BJ, [4]
 * CD, [5]
 * 
 * AH 3
 * CD 5
 * JK 2
 * Map: j = 1
 * AH, [3,3]
 * BJ, [4] --> [4,0]
 * CD, [5,5]
 * JK, [0,2]
 * 
 * AH 3
 * CD 5
 * JK 2
 * Map: j = 2
 * AH, [3,3,3]
 * BJ, [4] --> [4,0] --> [4,0,0]
 * CD, [5,5,5]
 * JK, [0,2,2] 
 */

