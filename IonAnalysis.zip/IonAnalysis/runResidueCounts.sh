#!/usr/bin/env bash

for file in Complexes/*; do
  filename="$(basename "$file")"
  output="${filename%.*}.csv"
  python3 ./getResidues.py $file -s "ResidueCounts/${output}"
done
